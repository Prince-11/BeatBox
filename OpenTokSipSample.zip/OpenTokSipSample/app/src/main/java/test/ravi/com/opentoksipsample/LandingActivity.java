package test.ravi.com.opentoksipsample;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;
import android.view.WindowManager;

public class LandingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_landing);
        Thread lTimer = new Thread() {
            public void run() {
                try {
                    int lTimer1 = 0;
                    while (lTimer1 < 5000) {
                        sleep(100);
                        lTimer1 = lTimer1 + 100;
                    }
                    startActivity(new Intent(LandingActivity.this, VoiceOnlyActivity.class));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    finish();
                }
            }
        };
        lTimer.start();
    }
}
