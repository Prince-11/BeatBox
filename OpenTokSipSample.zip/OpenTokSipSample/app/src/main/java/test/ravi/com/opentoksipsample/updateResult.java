package test.ravi.com.opentoksipsample;

/**
 * Created by admin on 6/8/2016.
 */
public interface updateResult {

    public void  updateResult(String str);
}
