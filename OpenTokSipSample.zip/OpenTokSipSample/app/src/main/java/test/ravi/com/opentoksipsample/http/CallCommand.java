package test.ravi.com.opentoksipsample.http;

import android.util.Log;

import test.ravi.com.opentoksipsample.config.OpenTokConfig;
import test.ravi.com.opentoksipsample.updateResult;


//import android.widget.Toast;

/**
 * Created by Ravi .
 */
public class CallCommand extends Command {

    public static final int READ_TIME = 10000;
    public static final int CONNECION_TIME = 15000;

    private  String mSipUri;
    //private Activity mActivity; Toast
    private updateResult mUpdateUI;

    public CallCommand(String sipURI, updateResult updateUI) {

        mUpdateUI = updateUI;
        mResultIntefac = new Result() {
            @Override
            public void updateResult(String result) {
                mResult = result;
                 mUpdateUI.updateResult(result);
            }
        };

       mURL = new String(OpenTokConfig.baseURL + OpenTokConfig.API_KEY + "/call");
        mSipUri = sipURI;
        execute();


    }

    @Override
    public void execute() {
//        mRequestPaaam = new

        //25d55ad283aa400af464c76d713c07ad
        StringBuilder requestBuilder = new StringBuilder();
        requestBuilder.append("{");
        requestBuilder.append("\"");
        requestBuilder.append("sessionId");
        requestBuilder.append("\":");
        requestBuilder.append("\"");
        requestBuilder.append(OpenTokConfig.SESSION_ID);
        requestBuilder.append("\"");
        requestBuilder.append(",");
        requestBuilder.append("\"");
        requestBuilder.append("token");
        requestBuilder.append("\":");
        requestBuilder.append("\"");
        requestBuilder.append(OpenTokConfig.TOKEN);
        requestBuilder.append("\"");
        requestBuilder.append(",");
        requestBuilder.append("\"");
        requestBuilder.append("sip");
        requestBuilder.append("\":");
        requestBuilder.append("{");
        requestBuilder.append("\"");
        requestBuilder.append("uri");
        requestBuilder.append("\":");
        requestBuilder.append("\"");
        requestBuilder.append("sip:" + mSipUri + ";transport=tls");
        requestBuilder.append("\"");
        requestBuilder.append(",");
        requestBuilder.append("\"");
        requestBuilder.append("secure");
        requestBuilder.append("\":");
        requestBuilder.append("false");
        requestBuilder.append("}");
        requestBuilder.append("}");

        Http http =   Http.getInstance();
        Log.d("Ravi", "request " + requestBuilder.toString());
     //  Toast.makeText(mActivity, requestBuilder.toString(), Toast.LENGTH_LONG).show();
        http.sendRequest(mURL, requestBuilder.toString(), mResultIntefac);


    }



}
