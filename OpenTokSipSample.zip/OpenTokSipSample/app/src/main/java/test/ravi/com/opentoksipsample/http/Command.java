package test.ravi.com.opentoksipsample.http;

/**
 * Created by Ravi.
 */
public abstract class Command implements ICommand{

    protected  String mURL;
    protected String mRequestParam;
    protected String mResult;
    protected Result mResultIntefac;
    public interface Result {
        public void updateResult(String result);
    }


}
