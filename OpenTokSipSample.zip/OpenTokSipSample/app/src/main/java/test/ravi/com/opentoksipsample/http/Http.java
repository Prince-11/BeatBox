package test.ravi.com.opentoksipsample.http;

import android.graphics.Bitmap;
import android.support.v4.util.LruCache;
import android.util.Log;


import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import test.ravi.com.opentoksipsample.config.OpenTokConfig;


public class Http {
	
	public static final int READ_TIME = 10000;
    public static final int CONNECION_TIME = 15000;
	private static int NUMBER_OF_CORES = Runtime.getRuntime().availableProcessors();
	private static int KEEP_ALIVE_TIME = 100;
	private static TimeUnit KEEP_ALIVE_TIME_UNIT = TimeUnit.SECONDS;
			
	private LruCache<String , Bitmap> mMemoryCache;
	private static Http mInstance;
	ThreadPoolExecutor mThreadPoolExecutor;
	private BlockingQueue<Runnable> mBlockingQueue;
//	private	ExecutorService mExecutorService;
	
	private Http() {
		mBlockingQueue = new LinkedBlockingQueue<Runnable>();
		mThreadPoolExecutor = new ThreadPoolExecutor(NUMBER_OF_CORES, NUMBER_OF_CORES, KEEP_ALIVE_TIME,
				KEEP_ALIVE_TIME_UNIT, mBlockingQueue);
	}


	public static Http getInstance() {
		if (mInstance == null) {//will make it safe for multithread
			mInstance = new Http();
		
		}
		
		return mInstance;
	}
	
	public void sendRequest(String url,String inputString, Command.Result command) {
		MyRunnable myRunnable = new MyRunnable(url, inputString, command);
		mThreadPoolExecutor.execute(myRunnable);
//		mBlockingQueue.add(bitmapLoaderRunnable);
//		mExecutorService.execute(bitmapLoaderRunnable);
	}
	
	
private class MyRunnable implements Runnable {
		private String mURL;
		private String mInputString;
		private Command.Result mResult;
		public MyRunnable(String url, String name, Command.Result result) {
			mInputString = name;
			mURL = url;
			mResult = result;
		}

		@Override
		public void run() {
			// TODO Auto-generated method stub

			URL url;
			try {
				url = new URL(mURL);
                HttpURLConnection httpURLConnection = null;
				try {
                    httpURLConnection = (HttpURLConnection)url.openConnection();
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setRequestProperty("Accept-Charset", "UTF-8");
                    httpURLConnection.setRequestProperty("Content-Type", "application/json");
					httpURLConnection.setRequestProperty("X-TB-PARTNER-AUTH", OpenTokConfig.API_KEY +":" +OpenTokConfig.API_SECRET_KEY);
                    httpURLConnection.setReadTimeout(READ_TIME);
                    httpURLConnection.setConnectTimeout(CONNECION_TIME);
                    httpURLConnection.connect();
                    DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
                    dataOutputStream.writeBytes(mInputString);
                    dataOutputStream.flush();
                    dataOutputStream.close();

                    try {
                        //Receive the response from the server
                        InputStream in = new BufferedInputStream(httpURLConnection.getInputStream());
                        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                        StringBuilder result = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            result.append(line);
                        }

//                        Log.d("JSON Parser", "result: " + result.toString());
					//	mResult.updateResult(result.toString());
						Log.d("Ravi", "response " + result.toString());
                        try {
                            JSONObject  jsonObject = new JSONObject(result.toString());
                            String sessionId =  jsonObject.getString("streamId");
							Log.d("Ravi", "stream_id " + sessionId);
                            mResult.updateResult(sessionId);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }



				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally {
                    if(httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                }
            } catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
	}

}
