package test.ravi.com.opentoksipsample.http;
public interface ICommand {

    public void execute();
}