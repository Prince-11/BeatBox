package test.ravi.com.opentoksipsample.config;

public class OpenTokConfig {

    // *** Fill the following variables using your own Project info from the OpenTok dashboard  ***
    // ***                      https://dashboard.tokbox.com/projects                           ***
    // Replace with a generated Session ID
    public static  String SESSION_ID = "1_MX40NTYxNTIzMn5-MTQ3MTkzMjU2OTM4MH5IWmpZREluN3FDUTFXcnRiNGYvSEgzaVJ-fg";
    // Replace with a generated token (from the dashboard or using an OpenTok server SDK)
    public static  String TOKEN = "T1==cGFydG5lcl9pZD00NTYxNTIzMiZzaWc9YWNlNTYwM2UwN2VmMzdhNjk0NDYwN2U3YzgyNWFhYTk5ZGI2NzcxZDpzZXNzaW9uX2lkPTFfTVg0ME5UWXhOVEl6TW41LU1UUTNNVGt6TWpVMk9UTTRNSDVJV21wWlJFbHVOM0ZEVVRGWGNuUmlOR1l2U0VnemFWSi1mZyZjcmVhdGVfdGltZT0xNDcxOTMyNjAzJm5vbmNlPTAuOTQzNTE1OTQyNDMxOTg2MyZyb2xlPXB1Ymxpc2hlciZleHBpcmVfdGltZT0xNDc0NTI0NjAy";
    // Replace with your OpenTok API key
    public static  String API_KEY = "45615232";

    public static  String API_SECRET_KEY = "78b0a53ab4b7f1691eb50bc85f9d90a909fca212";
    public static  String SIP_URI ="ravi.s@sip.linphone.org";
    // Subscribe to a stream published by this client. Set to false to subscribe
    // to other clients' streams only.
    public static final boolean SUBSCRIBE_TO_SELF = false;
    public static final String baseURL="http://api.opentok.com/v2/project/";


}
